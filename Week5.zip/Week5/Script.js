// Change text content dynamically when the "Change Text" button is clicked
const changeTextBtn = document.getElementById('changeTextBtn');
const textElement = document.getElementById('text');

changeTextBtn.addEventListener('click', () => {
    textElement.textContent = 'The text has been changed dynamically!';
});

// Modify CSS styles via JavaScript when the "Change Style" button is clicked
const changeStyleBtn = document.getElementById('changeStyleBtn');

changeStyleBtn.addEventListener('click', () => {
    textElement.style.color = 'blue';
    textElement.style.fontSize = '20px';
    textElement.style.fontWeight = 'bold';
});

// Add or remove an element when the corresponding buttons are clicked
const addElementBtn = document.getElementById('addElementBtn');
const removeElementBtn = document.getElementById('removeElementBtn');

addElementBtn.addEventListener('click', () => {
    const newElement = document.createElement('p');
    newElement.textContent = 'This is a newly added element!';
    document.getElementById('content').appendChild(newElement);
});

removeElementBtn.addEventListener('click', () => {
    const lastElement = document.querySelector('#content p:last-child');
    if (lastElement) {
        lastElement.remove();
    }
});
